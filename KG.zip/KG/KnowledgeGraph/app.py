from flask import Flask, render_template, request
import config
import os

app = Flask(__name__)
app.config.from_object(config)


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/LinkPrediction')
def LinkPrediction():
    return render_template('LinkPrediction.html')

@app.route('/LP_Introduction')
def LP_Introduction():
    return render_template('LP_Introduction.html')

@app.route('/LP_AppliScene')
def LP_AppliScene():
    return render_template('LP_AppliScene.html')

@app.route('/LP_Datasets')
def LP_Datasets():
    return render_template('LP_Datasets.html')

@app.route('/LP_Metrics')
def LP_Metrics():
    return render_template('LP_Metrics.html')

@app.route('/LP_Models')
def LP_Models():
    return render_template('LP_Models.html')

@app.route('/aa')
def aa():
    os.system('start')
    return "nothing"


if __name__ == '__main__':
    app.run()
